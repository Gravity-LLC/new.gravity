document.addEventListener('DOMContentLoaded', () =>{
	'use strict';
	new WOW().init();
	
	
})