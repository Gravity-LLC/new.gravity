// lange

export const initialLange = (payload) => ({type: 'INITIAL-LANGE', payload})
export const ruLange = () => ({type: 'RU-LANGE'})
export const enLange = () => ({type: 'EN-LANGE'})

// lange

// sideBar

export const sideBarTrue = ()=> ({type: 'SIDE-BAAR-TRUE'});
export const sideBarFalse = ()=> ({type: 'SIDE-BAAR-FALSE'});

// sideBar
