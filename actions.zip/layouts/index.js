import Main from './Main';
import Detiled from './Detiled'
export {
    Main,
    Detiled
}