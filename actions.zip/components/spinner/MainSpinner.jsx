import React from 'react';
import './spinners.css';
export default function MainSpinner() {
    return (
        <div className="mainSpinner d-flex justify-content-center align-items-center">
            <div>
            <img src="./assets/images/spinners/sp-1.gif" alt=""/>
            </div>
        </div>
    )
};
