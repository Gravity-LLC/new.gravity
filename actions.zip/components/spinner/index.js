import MainSpinner from './MainSpinner';
import AdminContentSpinner from './adminContentSpinner'
export {
    MainSpinner,
    AdminContentSpinner
}